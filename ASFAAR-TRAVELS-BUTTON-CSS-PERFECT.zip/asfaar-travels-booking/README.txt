=== Asfaar Travels Booking System ===
Contributors: Asfaar Travels
Tags: umrah, booking, travel
Requires at least: 5.8
Tested up to: 6.4
Requires PHP: 7.4
Stable tag: 2.0.0

Professional booking system.

== Description ==

Shortcode: [Asfaar_booking_System]

Features:
* 7-step booking
* Age validation
* Admin panel
* PDF & email

== Installation ==

1. Upload and activate
2. Add shortcode
3. Configure packages
