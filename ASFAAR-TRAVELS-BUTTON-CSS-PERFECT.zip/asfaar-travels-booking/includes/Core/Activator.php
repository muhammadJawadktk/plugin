<?php
namespace AsfaarTravels\Core;

if (!defined('ABSPATH')) exit;

class Activator {
    
    public static function activate() {
        global $wpdb;
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        $charset = $wpdb->get_charset_collate();
        
        // Packages table WITH image_url
        $table = $wpdb->prefix . 'asfaar_travels_packages';
        $sql = "CREATE TABLE IF NOT EXISTS $table (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            package_name varchar(255) NOT NULL,
            description longtext,
            price decimal(10,2) NOT NULL DEFAULT 0.00,
            duration varchar(100) DEFAULT '',
            category varchar(100) DEFAULT 'Economy',
            itinerary longtext,
            inclusions longtext,
            exclusions longtext,
            image_url varchar(500) DEFAULT '',
            status varchar(20) DEFAULT 'active',
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id)
        ) $charset;";
        dbDelta($sql);
        
        // Hotels table WITH image_url
        $table = $wpdb->prefix . 'asfaar_travels_hotels';
        $sql = "CREATE TABLE IF NOT EXISTS $table (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            name varchar(255) NOT NULL,
            city varchar(100) NOT NULL,
            star_rating int(11) DEFAULT 3,
            distance varchar(100) DEFAULT '',
            price_per_night decimal(10,2) DEFAULT 0.00,
            description longtext,
            amenities longtext,
            image_url varchar(500) DEFAULT '',
            status varchar(20) DEFAULT 'active',
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id)
        ) $charset;";
        dbDelta($sql);
        
        // Transports table
        $table = $wpdb->prefix . 'asfaar_travels_transports';
        $sql = "CREATE TABLE IF NOT EXISTS $table (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            name varchar(255) NOT NULL,
            type varchar(100) NOT NULL,
            description text,
            price_per_person decimal(10,2) NOT NULL,
            capacity int(11) DEFAULT 0,
            icon varchar(10) DEFAULT '🚗',
            status varchar(20) DEFAULT 'active',
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id)
        ) $charset;";
        dbDelta($sql);
        
        // Add default transports
        $count = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}afsar_transports");
        if ($count == 0) {
            $transports = [
                ['Private Car', 'car', 'Comfortable private vehicle', 800, 4, '🚗'],
                ['Shared Car', 'car', 'Economical shared vehicle', 500, 4, '🚙'],
                ['Standard Bus', 'bus', 'Comfortable bus service', 150, 50, '🚌'],
                ['VIP Bus', 'bus', 'Luxury bus experience', 250, 30, '🚐'],
                ['Hiace Van', 'van', 'Perfect for small groups', 350, 15, '🚐'],
                ['Coaster', 'bus', 'Medium-sized coach', 400, 25, '🚌']
            ];
            
            foreach ($transports as $t) {
                $wpdb->insert("{$wpdb->prefix}afsar_transports", [
                    'name' => $t[0], 'type' => $t[1], 'description' => $t[2],
                    'price_per_person' => $t[3], 'capacity' => $t[4], 'icon' => $t[5], 'status' => 'active'
                ], ['%s', '%s', '%s', '%f', '%d', '%s', '%s']);
            }
        }
        
        // Bookings table
        $table = $wpdb->prefix . 'asfaar_travels_bookings';
        $sql = "CREATE TABLE IF NOT EXISTS $table (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            booking_reference varchar(50) NOT NULL,
            package_id bigint(20),
            customer_name varchar(255) NOT NULL,
            customer_email varchar(255) NOT NULL,
            customer_phone varchar(50),
            adults int(11) DEFAULT 1,
            children int(11) DEFAULT 0,
            infants int(11) DEFAULT 0,
            total_price decimal(10,2) DEFAULT 0.00,
            booking_data longtext,
            pdf_path varchar(500),
            status varchar(20) DEFAULT 'pending',
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY booking_reference (booking_reference)
        ) $charset;";
        dbDelta($sql);
        
        add_option('afsar_currency', 'SAR');
        add_option('afsar_admin_email', get_option('admin_email'));
        flush_rewrite_rules();
    }
    
    public static function repair_database() {
        global $wpdb;
        $tables = ['afsar_packages', 'afsar_hotels', 'afsar_transports', 'afsar_bookings'];
        foreach ($tables as $table) {
            $wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}$table");
        }
        self::activate();
        return true;
    }
}
